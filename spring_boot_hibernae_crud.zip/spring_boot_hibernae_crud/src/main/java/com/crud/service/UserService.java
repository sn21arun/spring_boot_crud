package com.crud.service;

import com.crud.model.Response;
import com.crud.model.User;

public interface UserService {
	
	public Response createUser(User user);
}
