package com.crud.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.UserDao;
import com.crud.model.Response;
import com.crud.model.User;
import com.crud.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userdao;

	@Override
	public Response createUser(User user) {
		Response res = new Response();
		try {
			userdao.createUser(user);
			res.setErrormessage("Data Saved Successfully!!!");
		} catch (Exception e) {

			res.setErrormessage("Some problem occured!!");
			return res;
		}
		return res;
	}

}
