package com.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.crud.model.Response;
import com.crud.model.User;
import com.crud.service.UserService;

@Controller
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserService userservice;

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Response createUser(@RequestBody User user) {
		Response res = userservice.createUser(user);
		return res;
	}

}
