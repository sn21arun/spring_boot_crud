package com.crud.dao;

import com.crud.model.User;

public interface UserDao {
	
	public void createUser(User user);
}
