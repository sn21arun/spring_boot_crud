package com.crud.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.crud.dao.UserDao;
import com.crud.dao.model.UserDaoModel;
import com.crud.model.User;
import com.crud.repository.UserRepository;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	UserRepository userrepository;

	@Override
	public void createUser(User user) {
		UserDaoModel us = new UserDaoModel();
		us.setUsername(user.getUsername());
		userrepository.save(us);
	}

}
