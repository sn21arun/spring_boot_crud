package com.mkyong.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mkyong.dao.model.Login;
import com.mkyong.model.LoginRequest;
import com.mkyong.repository.LoginRepository;

@Controller
public class WelcomeController {

	@Autowired
	LoginRepository loginrepository;

	@RequestMapping(value = "/showlogin", method = RequestMethod.GET)
	public ModelAndView showLogin(LoginRequest loginreq, Map<String, String> model) {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("login");
		return modelandview;
	}

	@RequestMapping(value = "/processlogin", method = RequestMethod.POST)
	public ModelAndView processLogin(LoginRequest loginreq, Map<String, String> model) {
		ModelAndView modelandview = new ModelAndView();
		Login logindao = new Login();
		logindao.setUsername(loginreq.getUsername());
		loginrepository.save(logindao);
		model.put("message", loginreq.getUsername());
		modelandview.setViewName("welcome");
		return modelandview;
	}

}